console.log('Bienvenido a {{projectName}} creado por {{author}}');
